<!DOCTYPE html>
<html>
    <head>
    

<body>
	<div class="container">
<div class="row row">
    <div class="col-mid-6 col-md-offset-3">
			
				<input type="email" class="form-control" placeholder="email Address"/>
</div>
<div class="form-group ">
				<input type="submit" value="Generate New Password" class="btn btn-warning btn-block" placeholder="Enter your email Address"/>
</div>
</div>
</div>
</body>
</head>
<style>


.container{
	width: 500px;
	height: 450px;
	text-align: center;
	margin: 0 auto;
	background-color: #cff4fc;
	margin-top: 160px;
}

.container img{
	width: 150px;
	height: 150px;
	margin-top: -60px;
}

input[type="text"],input[type="password"]{
	margin-top: 30px;
	height: 45px;
	width: 300px;
	font-size: 18px;
	margin-bottom: 20px;
	background-color: #fff;
	padding-left: 40px;
}

.form-input::before{
	content: "\f007";
	font-family: "FontAwesome";
	padding-left: 07px;
	padding-top: 40px;
	position: absolute;
	font-size: 35px;
	color: #2980b9; 
}

.form-input:nth-child(2)::before{
	content: "\f023";
}

.btn-login{
	padding: 15px 25px;
	border: none;
	background-color: #27ae60;
	color: #fff;
}
.row{
    margin-right: -80px;
    margin-left: -80px;

}
.color{
    color:red;
    
}
</style>

</html>