<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<title>Digital Library</title>

<meta name="viewport" content="width=device-width,initial-scale=1">

<body>

<style>
.w3-sofia {
  font-family: Sofia, cursive;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="navbar">
<a href="updateprofile.php"><i class="fa fa-fw fa-user"></i> Profile</a>

</div>

<div class="w3-container w3-sofia">

  <h1 class>Digital Library Search Engine Using Wi-ki Cards</h1>
  
      <div class="container">
        <h2 class="text-center"> Welcome<strong><?php echo $_SESSION['name'];?></strong></h2>
      <div class="row">
        <div class="col-mid-6 col-md-offset-3">
          <form>
            <div class="form-group">
        <input id="text" class="form-control" placeholder="search" />
      </div>
      <button type="submit" class="col-md-offset-4 btn btn-primary" >Submit</button>
</form>
    </div>
  
</div>
</div>
</div>