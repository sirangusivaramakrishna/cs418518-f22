<!DOCTYPE html>
<html>
    <head>
    

<body>
	<div class="container">
<div class="row ">
		<form method='POST' action='#'>
			
				<input type="password" name="text" placeholder="password"/>	
				<input type="password" name="password" placeholder="re-enter password"/>
                <div class="form-group">
			    <input type="submit" value="SUBMIT" class="btn btn-warning btn-block"/>

</div>
<div class="col-md-12 control color">
<div style="padding-top:15px; font-size:85%" >
<a href="login.php"> Click here to Login</a>
</div>
</div>
</div>
</div>
</form>
	
</body>
</head>
<style>


.container{
	width: 500px;
	height: 450px;
	text-align: center;
	margin: 0 auto;
	background-color: #cff4fc;
	margin-top: 160px;
}

.container img{
	width: 150px;
	height: 150px;
	margin-top: -60px;
}

input[type="text"],input[type="password"]{
	margin-top: 30px;
	height: 45px;
	width: 300px;
	font-size: 18px;
	margin-bottom: 20px;
	background-color: #fff;
	padding-left: 40px;
}

.form-input::before{
	content: "\f007";
	font-family: "FontAwesome";
	padding-left: 07px;
	padding-top: 40px;
	position: absolute;
	font-size: 35px;
	color: #2980b9; 
}

.form-input:nth-child(2)::before{
	content: "\f023";
}

.btn-login{
	padding: 15px 25px;
	border: none;
	background-color: #27ae60;
	color: #fff;
}
.row{
    margin-right: -80px;
    margin-left: -80px;

}
.color{
    color:red;
    
}
</style>

</html>